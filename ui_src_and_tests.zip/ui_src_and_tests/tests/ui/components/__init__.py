"""Tests for UI components."""
