"""Tests for UI state management."""
