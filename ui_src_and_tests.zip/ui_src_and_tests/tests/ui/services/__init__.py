"""Tests for UI services."""
