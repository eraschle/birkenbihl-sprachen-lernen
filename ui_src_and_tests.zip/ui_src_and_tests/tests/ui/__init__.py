"""UI tests for Streamlit components."""
